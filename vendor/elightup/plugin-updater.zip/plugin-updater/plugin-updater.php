<?php
/**
 * Plugin Name: Plugin Updater
 * Description: Updater for single plugin from eLightUp.
 * Author:      eLightUp
 * Author URI:  https://elightup.com
 * Version:     1.0.0
 */

require __DIR__ . '/vendor/autoload.php';
